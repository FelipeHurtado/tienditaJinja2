#Mi tiendita con microservicios

Para ejecutar el proyecto en el terminal
<code>
docker-compose up
</code>

luego desde el navegador
<code>
http://localhost:8080/cliente/
</code>
         
<code>
http://localhost:8080/producto/
</code>
         
